package org.slk.cosmetics.UserDao;

import java.util.List;

import org.slk.cosmetics.model.User;

public interface UserDao {

	/* public List<User> viewAllUser(); */
	public static int loginvalidation(String email, String password) {
		// TODO Auto-generated method stub
		return 0;
	}
}
