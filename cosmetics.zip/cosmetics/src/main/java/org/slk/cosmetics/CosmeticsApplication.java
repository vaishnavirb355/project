package org.slk.cosmetics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CosmeticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CosmeticsApplication.class, args);
	}

}
