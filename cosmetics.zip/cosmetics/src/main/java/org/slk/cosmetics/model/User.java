package org.slk.cosmetics.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User {
	private long id;
    private boolean active;
    private String address;
    private String name;
    private String email;
    private String password;
    private String phone;
    private String role;
    
    
 
    public User(long id, boolean active, String address, String name, String email, String password, String phone,
			String role) {
		this.id = id;
		this.active = active;
		this.address = address;
		this.name = name;
		this.email = email;
		this.password = password;
		this.phone = phone;
		this.role = role;
	}
    public User() {
		super();
	}

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	    public long getId() {
		return id;
	}
    
	public void setId(long id) {
		this.id = id;
	}
	 @Column(name = "active")
	public boolean isActive() {
		return active;
	}
	

	public void setActive(boolean active) {
		this.active = active;
	}
	
	 @Column(name = "address", nullable = false)
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	 @Column(name = "name", nullable = false)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	 @Column(name = "email", nullable = false)
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	 @Column(name = "password", nullable = false)
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	 @Column(name = "phone", nullable = false)
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	 @Column(name = "role")
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", active=" + active + ", address=" + address + ", name=" + name + ", email=" + email
				+ ", password=" + password + ", phone=" + phone + ", role=" + role + "]";
	}
}
