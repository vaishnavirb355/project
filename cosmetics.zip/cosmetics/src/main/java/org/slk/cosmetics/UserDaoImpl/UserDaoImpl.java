package org.slk.cosmetics.UserDaoImpl;

import java.util.ArrayList;
import java.util.List;

import org.slk.cosmetics.UserDao.UserDao;
import org.slk.cosmetics.model.User;

public class UserDaoImpl implements UserDao {
    
	static List<User> list=new ArrayList();
	public int loginvalidation(String email,String password) {
		int flag=0;
		for(User u:list) {
			if(u.getEmail().equals(email) && u.getPassword().equals(password))
			{
				flag=1;
			}
		}
		System.out.println("flag"+flag);
		return flag;
	}
	
}
